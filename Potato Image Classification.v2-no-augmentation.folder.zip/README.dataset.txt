# Potato Image Classification > No Augmentation
https://universe.roboflow.com/classification/potato-image-classification

Provided by Roboflow
License: CC BY 4.0

